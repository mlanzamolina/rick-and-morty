import React from 'react'

export default function Footer() {
    return (
        <div>
            <h1>Marco Lanza <a href="https://github.com/mlanzamolina/rick-and-morty">Github</a></h1>
        </div>
    )
}
