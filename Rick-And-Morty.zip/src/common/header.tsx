import React from "react";

export default function Header(){
    return (
        <>
        <h1>
            Character List
        </h1>
        </>
    )
}